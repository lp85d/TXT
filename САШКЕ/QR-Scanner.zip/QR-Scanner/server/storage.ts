
import { scans, type InsertScan, type Scan } from "@shared/schema";
import { db } from "./db";
import { desc } from "drizzle-orm";

export interface IStorage {
  createScan(scan: InsertScan): Promise<Scan>;
  getScans(): Promise<Scan[]>;
}

export class DatabaseStorage implements IStorage {
  async createScan(insertScan: InsertScan): Promise<Scan> {
    const [scan] = await db
      .insert(scans)
      .values(insertScan)
      .returning();
    return scan;
  }

  async getScans(): Promise<Scan[]> {
    return await db
      .select()
      .from(scans)
      .orderBy(desc(scans.scannedAt));
  }
}

export const storage = new DatabaseStorage();
