
import { pgTable, text, serial, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const scans = pgTable("scans", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  format: varchar("format", { length: 50 }).notNull(), // 'QR_CODE', 'EAN_13', etc.
  scannedAt: timestamp("scanned_at").defaultNow(),
});

export const insertScanSchema = createInsertSchema(scans).pick({
  content: true,
  format: true,
});

export type Scan = typeof scans.$inferSelect;
export type InsertScan = z.infer<typeof insertScanSchema>;
