import { useScans } from "@/hooks/use-scans";
import { formatDistanceToNow } from "date-fns";
import { QrCode, Barcode, Calendar, Copy, ExternalLink, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function ScanHistory() {
  const { data: scans, isLoading, error } = useScans();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-48">
        <Loader2 className="w-8 h-8 animate-spin text-primary/50" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center p-8 bg-destructive/10 rounded-2xl border border-destructive/20">
        <p className="text-destructive font-medium">Failed to load history</p>
      </div>
    );
  }

  if (!scans || scans.length === 0) {
    return (
      <div className="text-center p-12 bg-secondary/30 rounded-3xl border border-dashed border-white/10">
        <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
          <QrCode className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-bold text-foreground">No scans yet</h3>
        <p className="text-muted-foreground mt-1">Your recent scans will appear here.</p>
      </div>
    );
  }

  // Group scans by date roughly (optional but nice) - simple list for now
  // Sorting is usually handled by API, assuming list is recent first
  const sortedScans = [...scans].sort((a, b) => 
    new Date(b.scannedAt!).getTime() - new Date(a.scannedAt!).getTime()
  );

  return (
    <div className="space-y-4 pb-20">
      <h2 className="text-2xl font-display font-bold px-1">Recent Scans</h2>
      
      <div className="space-y-3">
        {sortedScans.map((scan, index) => {
          const isUrl = scan.content.startsWith('http');
          const isQr = scan.format === 'QR_CODE';

          return (
            <motion.div
              key={scan.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="group bg-card hover:bg-card/80 transition-colors rounded-2xl p-4 border border-border/50 shadow-sm"
            >
              <div className="flex items-start gap-4">
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border",
                  isQr 
                    ? "bg-primary/10 border-primary/20 text-primary" 
                    : "bg-orange-500/10 border-orange-500/20 text-orange-500"
                )}>
                  {isQr ? <QrCode className="w-6 h-6" /> : <Barcode className="w-6 h-6" />}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground bg-secondary px-2 py-0.5 rounded-full">
                      {scan.format.replace('_', ' ')}
                    </span>
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {scan.scannedAt && formatDistanceToNow(new Date(scan.scannedAt), { addSuffix: true })}
                    </span>
                  </div>
                  
                  <p className="font-mono text-sm text-foreground truncate mb-3">
                    {scan.content}
                  </p>

                  <div className="flex items-center gap-2">
                    <Button 
                      size="sm" 
                      variant="secondary" 
                      className="h-8 text-xs rounded-lg"
                      onClick={() => {
                        navigator.clipboard.writeText(scan.content);
                      }}
                    >
                      <Copy className="w-3 h-3 mr-1.5" />
                      Copy
                    </Button>
                    
                    {isUrl && (
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-8 text-xs rounded-lg text-accent hover:text-accent hover:bg-accent/10"
                        onClick={() => window.open(scan.content, '_blank')}
                      >
                        <ExternalLink className="w-3 h-3 mr-1.5" />
                        Open
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
