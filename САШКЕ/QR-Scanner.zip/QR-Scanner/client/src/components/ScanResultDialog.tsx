import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Scan, Copy, ExternalLink, Share2, Check } from "lucide-react";
import { useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface ScanResultDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  result: {
    content: string;
    format: string;
  } | null;
  onScanAgain: () => void;
}

export function ScanResultDialog({ isOpen, onOpenChange, result, onScanAgain }: ScanResultDialogProps) {
  const [copied, setCopied] = useState(false);

  if (!result) return null;

  const isUrl = (text: string) => {
    try {
      new URL(text);
      return true;
    } catch {
      return false;
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(result.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenLink = () => {
    window.open(result.content, '_blank', 'noopener,noreferrer');
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Scanned Code',
          text: result.content,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      handleCopy();
    }
  };

  const isEan = result.format.includes('EAN') || result.format.includes('UPC');
  const isQr = result.format.includes('QR');
  const urlDetected = isUrl(result.content);

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-card border-border/50 shadow-2xl p-0 overflow-hidden gap-0 rounded-3xl">
        {/* Header Visual */}
        <div className="h-32 bg-gradient-to-br from-primary/20 via-primary/10 to-transparent flex items-center justify-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary via-transparent to-transparent" />
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center shadow-lg shadow-primary/25 z-10"
          >
            {isQr ? <Scan className="w-8 h-8 text-primary-foreground" /> : <span className="text-2xl font-bold text-primary-foreground">|||</span>}
          </motion.div>
        </div>

        <div className="p-6">
          <DialogHeader className="mb-4">
            <div className="flex items-center justify-between">
              <span className={cn(
                "text-xs font-mono px-2 py-1 rounded-md uppercase tracking-wider",
                isEan ? "bg-orange-500/10 text-orange-400 border border-orange-500/20" : "bg-blue-500/10 text-blue-400 border border-blue-500/20"
              )}>
                {result.format}
              </span>
              <span className="text-xs text-muted-foreground font-medium">Just now</span>
            </div>
            <DialogTitle className="mt-2 text-xl font-bold tracking-tight">Scan Result</DialogTitle>
          </DialogHeader>

          <div className="bg-secondary/50 rounded-xl p-4 border border-white/5 mb-6">
            <p className="font-mono text-sm break-all text-secondary-foreground leading-relaxed">
              {result.content}
            </p>
          </div>

          <div className="flex flex-col gap-3">
            {urlDetected && (
              <Button 
                onClick={handleOpenLink}
                className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold h-12 rounded-xl"
              >
                <ExternalLink className="mr-2 w-4 h-4" />
                Open Link
              </Button>
            )}

            <div className="flex gap-3">
              <Button 
                variant="outline" 
                onClick={handleCopy}
                className="flex-1 h-12 rounded-xl border-white/10 hover:bg-white/5 hover:text-white"
              >
                {copied ? <Check className="mr-2 w-4 h-4 text-green-500" /> : <Copy className="mr-2 w-4 h-4" />}
                {copied ? "Copied" : "Copy"}
              </Button>
              <Button 
                variant="outline" 
                onClick={handleShare}
                className="flex-1 h-12 rounded-xl border-white/10 hover:bg-white/5 hover:text-white"
              >
                <Share2 className="mr-2 w-4 h-4" />
                Share
              </Button>
            </div>

            <Button 
              variant="ghost" 
              onClick={onScanAgain}
              className="mt-2 h-12 rounded-xl text-muted-foreground hover:text-foreground"
            >
              Scan Another Code
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
