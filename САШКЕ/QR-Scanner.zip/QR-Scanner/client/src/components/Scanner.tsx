import { useEffect, useRef, useState } from "react";
import { Html5Qrcode, Html5QrcodeSupportedFormats } from "html5-qrcode";
import { motion } from "framer-motion";
import { ScanLine, Loader2, Maximize2 } from "lucide-react";

interface ScannerProps {
  onScan: (decodedText: string, decodedResult: any) => void;
  isScanning?: boolean;
}

export function Scanner({ onScan, isScanning = true }: ScannerProps) {
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const [mounted, setMounted] = useState(false);
  const [permissionError, setPermissionError] = useState<string | null>(null);

  useEffect(() => {
    setMounted(true);
    return () => {
      if (scannerRef.current && scannerRef.current.isScanning) {
        scannerRef.current.stop().catch(console.error);
      }
    };
  }, []);

  useEffect(() => {
    if (!mounted || !isScanning) return;

    const startScanner = async () => {
      try {
        if (!scannerRef.current) {
          scannerRef.current = new Html5Qrcode("reader");
        }

        const config = {
          fps: 20,
          qrbox: (viewfinderWidth: number, viewfinderHeight: number) => {
            const minEdge = Math.min(viewfinderWidth, viewfinderHeight);
            const size = Math.floor(minEdge * 0.7);
            return { width: size, height: size };
          },
          aspectRatio: 1.0,
        };

        const onScanSuccess = (decodedText: string, decodedResult: any) => {
          if (navigator.vibrate) navigator.vibrate(200);
          onScan(decodedText, decodedResult);
        };

        // Attempt to start camera immediately
        await scannerRef.current.start(
          { facingMode: "environment" },
          config,
          onScanSuccess,
          () => {} // Ignore parse errors
        );
      } catch (err) {
        console.error("Scanner error:", err);
        setPermissionError("Не удалось получить доступ к камере. Пожалуйста, разрешите доступ.");
      }
    };

    startScanner();

    return () => {
      if (scannerRef.current && scannerRef.current.isScanning) {
        scannerRef.current.stop().catch(console.error);
      }
    };
  }, [mounted, isScanning, onScan]);

  return (
    <div className="relative w-full aspect-square max-w-sm mx-auto overflow-hidden rounded-3xl bg-black border border-white/10 shadow-2xl shadow-primary/20">
      <div id="reader" className="w-full h-full bg-black" />

      {/* Permission Error State */}
      {permissionError && (
        <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-background/90 z-20">
          <Maximize2 className="w-12 h-12 text-destructive mb-4" />
          <h3 className="text-lg font-bold text-foreground">Camera Access Required</h3>
          <p className="text-muted-foreground mt-2 text-sm">{permissionError}</p>
        </div>
      )}

      {/* Decorative Overlay */}
      <div className="absolute inset-0 pointer-events-none z-10">
        {/* Corners */}
        <div className="absolute top-6 left-6 w-8 h-8 border-t-4 border-l-4 border-accent rounded-tl-xl" />
        <div className="absolute top-6 right-6 w-8 h-8 border-t-4 border-r-4 border-accent rounded-tr-xl" />
        <div className="absolute bottom-6 left-6 w-8 h-8 border-b-4 border-l-4 border-accent rounded-bl-xl" />
        <div className="absolute bottom-6 right-6 w-8 h-8 border-b-4 border-r-4 border-accent rounded-br-xl" />

        {/* Scanning Animation */}
        <motion.div
          animate={{
            top: ["10%", "90%", "10%"],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "linear",
          }}
          className="absolute left-[10%] right-[10%] h-0.5 bg-accent shadow-[0_0_15px_2px_rgba(0,255,255,0.5)]"
        />
        
        {/* Status Text */}
        <div className="absolute bottom-12 left-0 right-0 text-center">
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-black/50 backdrop-blur-md text-xs font-medium text-white/80 border border-white/10">
            <ScanLine className="w-3 h-3 animate-pulse text-accent" />
            Scanning...
          </span>
        </div>
      </div>

      {!mounted && (
        <div className="absolute inset-0 flex items-center justify-center bg-secondary">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      )}
    </div>
  );
}
