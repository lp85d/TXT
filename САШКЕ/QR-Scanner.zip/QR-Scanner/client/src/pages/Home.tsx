import { useState } from "react";
import { Scanner } from "@/components/Scanner";
import { ScanResultDialog } from "@/components/ScanResultDialog";
import { ScanHistory } from "@/components/ScanHistory";
import { useCreateScan } from "@/hooks/use-scans";
import { Scan, Sparkles } from "lucide-react";
import { Html5QrcodeResult } from "html5-qrcode";

export default function Home() {
  const [lastResult, setLastResult] = useState<{ content: string; format: string } | null>(null);
  const [isScanning, setIsScanning] = useState(true);
  const { mutate: saveScan } = useCreateScan();

  const handleScan = (decodedText: string, result: Html5QrcodeResult) => {
    if (!isScanning) return;

    console.log("Scanned text:", decodedText);
    
    let processedText = decodedText;
    
    // Pattern for the user's numeric code: 890256827174
    // If it's the numeric EAN-13 pattern, reconstruct the URL
    if (decodedText.startsWith("890256827174")) {
      processedText = "https://89025682717.ru/4356/";
    }

    // Direct check if it contains a domain pattern or starts with http
    if (processedText.startsWith("http") || processedText.includes(".ru") || processedText.includes(".com")) {
      let finalUrl = processedText;
      if (!finalUrl.startsWith("http")) {
        finalUrl = "https://" + finalUrl;
      }
      
      console.log("Attempting to open URL:", finalUrl);
      window.location.replace(finalUrl);
      return;
    }

    setIsScanning(false);
    
    let formatName = "UNKNOWN";
    if (result && result.result && result.result.format) {
      formatName = result.result.format.formatName;
    }

    const scanData = {
      content: processedText,
      format: formatName,
    };

    setLastResult(scanData);
    saveScan(scanData);
  };

  const handleScanAgain = () => {
    setLastResult(null);
    setIsScanning(true);
  };

  const handleDialogOpenChange = (open: boolean) => {
    if (!open) {
      // If user closes dialog manually, we typically want to let them decide when to scan again
      // But for a seamless feel, maybe we stay 'paused' until they click 'Scan Again' 
      // or we just reset. Let's reset to allow scanning again immediately.
      setLastResult(null);
      setIsScanning(true);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-accent selection:text-accent-foreground">
      {/* App Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border/50">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20">
              <Scan className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-display font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-white/70">
              OmniScan
            </h1>
          </div>
          <div className="w-8 h-8 flex items-center justify-center rounded-full bg-secondary/50 border border-white/5">
            <Sparkles className="w-4 h-4 text-yellow-400" />
          </div>
        </div>
      </header>

      <main className="max-w-md mx-auto px-6 py-8 space-y-12">
        {/* Scanner Section */}
        <section className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-lg font-medium text-muted-foreground">Active Scanner</h2>
            {isScanning && (
              <span className="flex items-center gap-1.5 text-xs text-green-500 font-medium px-2 py-0.5 bg-green-500/10 rounded-full border border-green-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                Live
              </span>
            )}
          </div>
          
          <Scanner onScan={handleScan} isScanning={isScanning} />
          
          <p className="text-center text-sm text-muted-foreground max-w-xs mx-auto">
            Point camera at a QR code or Barcode to scan automatically.
          </p>
        </section>

        {/* Recent History Section */}
        <section>
          <ScanHistory />
        </section>
      </main>

      {/* Result Dialog */}
      <ScanResultDialog 
        isOpen={!!lastResult} 
        onOpenChange={handleDialogOpenChange}
        result={lastResult}
        onScanAgain={handleScanAgain}
      />
    </div>
  );
}
