
import tkinter as tk
from tkinter import messagebox
import qrcode
from PIL import Image, ImageTk, ImageDraw, ImageFont
import os
import hashlib

class QRCodeGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("Генератор QR-кодов")
        self.root.geometry("800x600")
        self.root.configure(bg="#2b2d31")

        self.existing_urls = set()
        self.rows = []
        self.cache_dir = os.path.join(os.getcwd(), "qr_cache")
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)

        self.qr_size = 200

        # Основной фрейм
        main_frame = tk.Frame(root, bg="#2b2d31")
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Заголовок
        tk.Label(main_frame, text="Генератор QR-кодов", font=("Helvetica", 16, "bold"),
                 bg="#2b2d31", fg="#e5e7eb").pack(pady=(0, 15))

        # Фрейм для списка
        self.scrollable_frame = tk.Frame(main_frame, bg="#313338")
        self.scrollable_frame.pack(fill="both", expand=True)

        # Заголовки
        header_frame = tk.Frame(self.scrollable_frame, bg="#1f2023")
        header_frame.pack(fill="x")
        tk.Label(header_frame, text="Ссылки", font=("Helvetica", 10, "bold"),
                 bg="#1f2023", fg="#e5e7eb", anchor="w", padx=10).pack(side="left", fill="x", expand=True)
        tk.Label(header_frame, text="QR-код", font=("Helvetica", 10, "bold"),
                 bg="#1f2023", fg="#e5e7eb", width=15).pack(side="right")

        # Кнопки
        button_frame = tk.Frame(main_frame, bg="#2b2d31")
        button_frame.pack(fill="x", pady=10)

        tk.Button(button_frame, text="Вставить из буфера", command=self.paste_from_clipboard,
                  font=("Helvetica", 10, "bold"), bg="#f59e0b", fg="white").pack(side="left", padx=5, expand=True)
        tk.Button(button_frame, text="Генерировать", command=self.generate_qrcodes,
                  font=("Helvetica", 10, "bold"), bg="#10b981", fg="white").pack(side="left", padx=5, expand=True)
        tk.Button(button_frame, text="Очистить", command=self.clear_list,
                  font=("Helvetica", 10, "bold"), bg="#ef4444", fg="white").pack(side="left", padx=5, expand=True)

    def add_row(self, url):
        row_frame = tk.Frame(self.scrollable_frame, bg="#313338")
        row_frame.pack(fill="x", padx=5, pady=2)

        url_label = tk.Label(row_frame, text=url, font=("Helvetica", 9), bg="#313338", fg="#d1d5db", anchor="w", padx=5)
        url_label.pack(side="left", fill="both", expand=True)

        qr_label = tk.Label(row_frame, bg="#313338")
        qr_label.pack(side="right", padx=5)

        self.rows.append((url_label, qr_label))

    def paste_from_clipboard(self):
        try:
            clipboard_text = self.root.clipboard_get()
            urls = [line.strip() for line in clipboard_text.splitlines() if line.strip()]
            for url in urls:
                if url not in self.existing_urls:
                    self.existing_urls.add(url)
                    self.add_row(url)
        except tk.TclError:
            pass

    def clear_list(self):
        for widget in self.scrollable_frame.winfo_children():
            if widget.winfo_class() == 'Frame' and widget != self.scrollable_frame.winfo_children()[0]: # Keep header
                widget.destroy()
        self.rows = []
        self.existing_urls = set()

    def generate_qrcodes(self):
        for url_label, qr_label in self.rows:
            url = url_label.cget("text")
            
            try:
                # Generate QR Code
                qr = qrcode.QRCode(
                    version=1,
                    error_correction=qrcode.constants.ERROR_CORRECT_L,
                    box_size=10,
                    border=4,
                )
                qr.add_data(url)
                qr.make(fit=True)

                img = qr.make_image(fill_color="black", back_color="white").convert('RGB')
                
                # Add text label at the bottom
                draw = ImageDraw.Draw(img)
                width, height = img.size
                
                # Resize if too big
                max_size = 200
                if width > max_size:
                    ratio = max_size / width
                    img = img.resize((max_size, int(height * ratio)), Image.LANCZOS)
                
                unique_id = hashlib.md5(url.encode()).hexdigest()
                fullname = os.path.join(self.cache_dir, f"{unique_id}.png")
                img.save(fullname)

                # Display in GUI
                photo = ImageTk.PhotoImage(img)
                qr_label.config(image=photo)
                qr_label.image = photo

            except Exception as e:
                print(f"Error generating for {url}: {str(e)}")

if __name__ == "__main__":
    try:
        import qrcode
    except ImportError:
        print("Please install 'qrcode' and 'pillow' libraries: pip install qrcode[pil] pillow")
        exit(1)

    root = tk.Tk()
    app = QRCodeGenerator(root)
    root.mainloop()
