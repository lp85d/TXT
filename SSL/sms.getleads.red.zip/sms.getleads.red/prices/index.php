<?php
// Файл логов в корне сайта
$log_file = __DIR__ . '/error_log.txt';

// Функция для записи логов
function write_log($message) {
    global $log_file;
    file_put_contents($log_file, date("[Y-m-d H:i:s] ") . $message . PHP_EOL, FILE_APPEND);
}

// Разрешаем CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Authorization, Content-Type");

// Запрашиваемый URL
$api_url = "https://sms-back-qu0k.onrender.com/prices";
$query = $_SERVER['QUERY_STRING'];
if (!empty($query)) {
    $api_url .= '?' . $query;
}

// Логируем URL запроса
write_log("Запрос на: $api_url");

// Запрос через cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
$response = curl_exec($ch);

// Проверяем ошибки cURL
if ($response === false) {
    write_log("Ошибка cURL: " . curl_error($ch));
}

// Определяем HTTP-код ответа
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
http_response_code($http_code);

// Логируем HTTP-код ответа
write_log("HTTP-код ответа: $http_code");

// Дублируем CORS-заголовки перед отправкой ответа
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

echo $response;
?>
