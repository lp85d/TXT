<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title> Пример простой страницы html</title>
</head>
<body>
    34324324
</body>
</html>